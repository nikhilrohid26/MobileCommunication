clear; clc; close all;

% === CONFIGURATION ===
numUEs = 150;
numGNBs = 5;
areaSize = 100;
timeSteps = 30;  % FL rounds
inputSize = 10; hiddenSize = 16; outputSize = 2;
localEpochs = 5; learningRate = 0.05;

rng(42);
UE_pos = rand(numUEs, 2) * areaSize;
theta = rand(numUEs, 1) * 2 * pi;
UE_velocity = [cos(theta), sin(theta)] * 2;

% gNB positions
gNB_pos = [20 20; 20 80; 50 50; 80 20; 80 80];

% Initialize logs
handoverCount = zeros(numUEs, 1);
prevGNB = zeros(numUEs, 1);
accList = zeros(timeSteps,1); lossList = zeros(timeSteps,1);
csvName = 'UE_FL_Data.csv';
fid = fopen(csvName, 'w');
fprintf(fid, 'NodeID,gNodeBID,QoS,Traffic,SINR,Latency,Jitter,PacketLoss,Battery,MobilitySpeed,Label\n');

% Animation
gifname = 'UE_Mobility_FL.gif';
colors = lines(numGNBs);

for round = 1:timeSteps
    % === MOBILITY UPDATE ===
    UE_pos = UE_pos + UE_velocity + 0.3*randn(size(UE_velocity));
    UE_pos = mod(UE_pos, areaSize);

    % gNB assignment
    distances = pdist2(UE_pos, gNB_pos);
    [minDist, assignedGNB] = min(distances, [], 2);

    for i = 1:numUEs
        if prevGNB(i) ~= 0 && prevGNB(i) ~= assignedGNB(i)
            handoverCount(i) = handoverCount(i) + 1;
        end
    end
    prevGNB = assignedGNB;

    % === FEATURES ===
    qos = rand(numUEs,1);
    traffic = 10 + rand(numUEs,1)*90;
    sinr = 10 + 20 * exp(-0.03 * minDist);
    latency = 5 + randn(numUEs,1);
    jitter = 1 + 0.2 * latency + rand(numUEs,1);
    pktLoss = rand(numUEs,1) * 5;
    battery = randi([40 100], numUEs,1);
    mobility = vecnorm(UE_velocity, 2, 2) * 3.6;

    label = double(qos > 0.5);  % 1 for high QoS
    label_onehot = [label == 0, label == 1];

    for i = 1:numUEs
        fprintf(fid, '%d,%d,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%d,%.2f,%d\n', ...
            i, assignedGNB(i), qos(i), traffic(i), sinr(i), latency(i), jitter(i), pktLoss(i), battery(i), mobility(i), label(i));
    end

    % === FL INPUT FEATURES ===
    X = [qos, traffic/100, sinr/30, latency/15, jitter/10, pktLoss/5, battery/100, mobility/100, rand(numUEs,2)];

    % === LOCAL TRAINING ===
    localWeights = cell(numUEs,1);
    for i = 1:numUEs
        W1 = randn(hiddenSize, inputSize) * sqrt(2/inputSize);
        b1 = zeros(hiddenSize,1);
        W2 = randn(outputSize, hiddenSize) * sqrt(2/hiddenSize);
        b2 = zeros(outputSize,1);
        x = X(i,:)'; y = label_onehot(i,:)';
        for e = 1:localEpochs
            z1 = W1 * x + b1; a1 = max(0, z1);
            z2 = W2 * a1 + b2; a2 = softmax(z2);
            dz2 = a2 - y;
            dW2 = dz2 * a1'; db2 = dz2;
            da1 = W2' * dz2;
            dz1 = da1 .* (z1 > 0);
            dW1 = dz1 * x'; db1 = dz1;
            W1 = W1 - learningRate * dW1;
            b1 = b1 - learningRate * db1;
            W2 = W2 - learningRate * dW2;
            b2 = b2 - learningRate * db2;
        end
        localWeights{i} = struct('W1', W1, 'b1', b1, 'W2', W2, 'b2', b2);
    end

    % === FEDAVG ===
    agg = localWeights{1};
    for i = 2:numUEs
        agg.W1 = agg.W1 + localWeights{i}.W1;
        agg.b1 = agg.b1 + localWeights{i}.b1;
        agg.W2 = agg.W2 + localWeights{i}.W2;
        agg.b2 = agg.b2 + localWeights{i}.b2;
    end
    agg.W1 = agg.W1 / numUEs; agg.b1 = agg.b1 / numUEs;
    agg.W2 = agg.W2 / numUEs; agg.b2 = agg.b2 / numUEs;

    % === EVALUATION ===
    correct = 0; loss = 0;
    for i = 1:numUEs
        x = X(i,:)'; y = label_onehot(i,:)';
        a1 = max(0, agg.W1 * x + agg.b1);
        a2 = softmax(agg.W2 * a1 + agg.b2);
        [~, pred] = max(a2); [~, actual] = max(y);
        if pred == actual, correct = correct + 1; end
        loss = loss - sum(y .* log(a2 + 1e-9));
    end
    accList(round) = 100 * correct / numUEs;
    lossList(round) = loss / numUEs;
    fprintf("🌍 Round %d | ✅ Accuracy: %.2f%% | Loss: %.4f\n", round, accList(round), lossList(round));

    % === ANIMATION ===
    figure(1); clf; hold on;
    for g = 1:numGNBs
        rectangle('Position', [gNB_pos(g,1)-15, gNB_pos(g,2)-15, 30, 30], ...
                  'EdgeColor', 'k', 'LineStyle', '--');
        plot(gNB_pos(g,1), gNB_pos(g,2), '^k', 'MarkerSize', 12, 'MarkerFaceColor', 'k');
        idx = find(assignedGNB == g);
        scatter(UE_pos(idx,1), UE_pos(idx,2), 36, colors(g,:), 'filled');
    end
    title(sprintf('UE Mobility - Round %d', round));
    xlim([0 areaSize]); ylim([0 areaSize]); drawnow;

    % Save to GIF
    frame = getframe(gcf); im = frame2im(frame);
    [imind, cm] = rgb2ind(im, 256);
    if round == 1
        imwrite(imind, cm, gifname, 'gif', 'Loopcount', inf, 'DelayTime', 1.2);

    else
        imwrite(imind, cm, gifname, 'gif', 'WriteMode', 'append', 'DelayTime', 1.2);  % Slower

    end
end

fclose(fid);

% === PLOT LEARNING CURVES ===
figure;
subplot(1,2,1);
plot(1:timeSteps, accList, '-o', 'LineWidth', 2); grid on;
xlabel('Round'); ylabel('Accuracy (%)'); title('FL Accuracy per Round');

subplot(1,2,2);
plot(1:timeSteps, lossList, '-s', 'LineWidth', 2); grid on;
xlabel('Round'); ylabel('Loss'); title('FL Loss per Round');

% === SOFTMAX FUNCTION ===
function out = softmax(x)
    ex = exp(x - max(x));
    out = ex / sum(ex);
end
